const base_url = "http://localhost:3000";

export default base_url