/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/movie/route";
exports.ids = ["app/api/movie/route"];
exports.modules = {

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("mongoose");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "../app-render/work-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/server/app-render/work-async-storage.external.js" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ "./work-unit-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist/server/app-render/work-unit-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fmovie%2Froute&page=%2Fapi%2Fmovie%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fmovie%2Froute.js&appDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fmovie%2Froute&page=%2Fapi%2Fmovie%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fmovie%2Froute.js&appDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),\n/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(rsc)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var C_Users_lenovo_Downloads_zip_2_src_app_api_movie_route_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/app/api/movie/route.js */ \"(rsc)/./src/app/api/movie/route.js\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/movie/route\",\n        pathname: \"/api/movie\",\n        filename: \"route\",\n        bundlePath: \"app/api/movie/route\"\n    },\n    resolvedPagePath: \"C:\\\\Users\\\\lenovo\\\\Downloads\\\\zip 2\\\\src\\\\app\\\\api\\\\movie\\\\route.js\",\n    nextConfigOutput,\n    userland: C_Users_lenovo_Downloads_zip_2_src_app_api_movie_route_js__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        workAsyncStorage,\n        workUnitAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIvaW5kZXguanM/bmFtZT1hcHAlMkZhcGklMkZtb3ZpZSUyRnJvdXRlJnBhZ2U9JTJGYXBpJTJGbW92aWUlMkZyb3V0ZSZhcHBQYXRocz0mcGFnZVBhdGg9cHJpdmF0ZS1uZXh0LWFwcC1kaXIlMkZhcGklMkZtb3ZpZSUyRnJvdXRlLmpzJmFwcERpcj1DJTNBJTVDVXNlcnMlNUNsZW5vdm8lNUNEb3dubG9hZHMlNUN6aXAlMjAyJTVDc3JjJTVDYXBwJnBhZ2VFeHRlbnNpb25zPXRzeCZwYWdlRXh0ZW5zaW9ucz10cyZwYWdlRXh0ZW5zaW9ucz1qc3gmcGFnZUV4dGVuc2lvbnM9anMmcm9vdERpcj1DJTNBJTVDVXNlcnMlNUNsZW5vdm8lNUNEb3dubG9hZHMlNUN6aXAlMjAyJmlzRGV2PXRydWUmdHNjb25maWdQYXRoPXRzY29uZmlnLmpzb24mYmFzZVBhdGg9JmFzc2V0UHJlZml4PSZuZXh0Q29uZmlnT3V0cHV0PSZwcmVmZXJyZWRSZWdpb249Jm1pZGRsZXdhcmVDb25maWc9ZTMwJTNEISIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUErRjtBQUN2QztBQUNxQjtBQUNtQjtBQUNoRztBQUNBO0FBQ0E7QUFDQSx3QkFBd0IseUdBQW1CO0FBQzNDO0FBQ0EsY0FBYyxrRUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsWUFBWTtBQUNaLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxRQUFRLHNEQUFzRDtBQUM5RDtBQUNBLFdBQVcsNEVBQVc7QUFDdEI7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUMwRjs7QUFFMUYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hc3NpZ25tZW50ZnVsbC8/YWRhOSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcHBSb3V0ZVJvdXRlTW9kdWxlIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvcm91dGUtbW9kdWxlcy9hcHAtcm91dGUvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1raW5kXCI7XG5pbXBvcnQgeyBwYXRjaEZldGNoIGFzIF9wYXRjaEZldGNoIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvbGliL3BhdGNoLWZldGNoXCI7XG5pbXBvcnQgKiBhcyB1c2VybGFuZCBmcm9tIFwiQzpcXFxcVXNlcnNcXFxcbGVub3ZvXFxcXERvd25sb2Fkc1xcXFx6aXAgMlxcXFxzcmNcXFxcYXBwXFxcXGFwaVxcXFxtb3ZpZVxcXFxyb3V0ZS5qc1wiO1xuLy8gV2UgaW5qZWN0IHRoZSBuZXh0Q29uZmlnT3V0cHV0IGhlcmUgc28gdGhhdCB3ZSBjYW4gdXNlIHRoZW0gaW4gdGhlIHJvdXRlXG4vLyBtb2R1bGUuXG5jb25zdCBuZXh0Q29uZmlnT3V0cHV0ID0gXCJcIlxuY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgQXBwUm91dGVSb3V0ZU1vZHVsZSh7XG4gICAgZGVmaW5pdGlvbjoge1xuICAgICAgICBraW5kOiBSb3V0ZUtpbmQuQVBQX1JPVVRFLFxuICAgICAgICBwYWdlOiBcIi9hcGkvbW92aWUvcm91dGVcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL2FwaS9tb3ZpZVwiLFxuICAgICAgICBmaWxlbmFtZTogXCJyb3V0ZVwiLFxuICAgICAgICBidW5kbGVQYXRoOiBcImFwcC9hcGkvbW92aWUvcm91dGVcIlxuICAgIH0sXG4gICAgcmVzb2x2ZWRQYWdlUGF0aDogXCJDOlxcXFxVc2Vyc1xcXFxsZW5vdm9cXFxcRG93bmxvYWRzXFxcXHppcCAyXFxcXHNyY1xcXFxhcHBcXFxcYXBpXFxcXG1vdmllXFxcXHJvdXRlLmpzXCIsXG4gICAgbmV4dENvbmZpZ091dHB1dCxcbiAgICB1c2VybGFuZFxufSk7XG4vLyBQdWxsIG91dCB0aGUgZXhwb3J0cyB0aGF0IHdlIG5lZWQgdG8gZXhwb3NlIGZyb20gdGhlIG1vZHVsZS4gVGhpcyBzaG91bGRcbi8vIGJlIGVsaW1pbmF0ZWQgd2hlbiB3ZSd2ZSBtb3ZlZCB0aGUgb3RoZXIgcm91dGVzIHRvIHRoZSBuZXcgZm9ybWF0LiBUaGVzZVxuLy8gYXJlIHVzZWQgdG8gaG9vayBpbnRvIHRoZSByb3V0ZS5cbmNvbnN0IHsgd29ya0FzeW5jU3RvcmFnZSwgd29ya1VuaXRBc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzIH0gPSByb3V0ZU1vZHVsZTtcbmZ1bmN0aW9uIHBhdGNoRmV0Y2goKSB7XG4gICAgcmV0dXJuIF9wYXRjaEZldGNoKHtcbiAgICAgICAgd29ya0FzeW5jU3RvcmFnZSxcbiAgICAgICAgd29ya1VuaXRBc3luY1N0b3JhZ2VcbiAgICB9KTtcbn1cbmV4cG9ydCB7IHJvdXRlTW9kdWxlLCB3b3JrQXN5bmNTdG9yYWdlLCB3b3JrVW5pdEFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MsIHBhdGNoRmV0Y2gsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fmovie%2Froute&page=%2Fapi%2Fmovie%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fmovie%2Froute.js&appDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(rsc)/./src/app/api/movie/route.js":
/*!************************************!*\
  !*** ./src/app/api/movie/route.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ GET),\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\n/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../lib/db */ \"(rsc)/./src/app/lib/db.js\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _lib_models_movie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/models/movie */ \"(rsc)/./src/app/lib/models/movie.js\");\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n/* harmony import */ var _middleware_authenticateToken__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../middleware/authenticateToken */ \"(rsc)/./src/app/middleware/authenticateToken.js\");\n\n\n\n\n\n// Function to connect to the database\nasync function connectDB() {\n    if ((mongoose__WEBPACK_IMPORTED_MODULE_1___default().connection).readyState === 0) {\n        await mongoose__WEBPACK_IMPORTED_MODULE_1___default().connect(_lib_db__WEBPACK_IMPORTED_MODULE_0__.connectionString);\n    }\n}\nasync function GET(req) {\n    await connectDB();\n    const authResult = (0,_middleware_authenticateToken__WEBPACK_IMPORTED_MODULE_4__.authenticate)(req);\n    if (!authResult.success) {\n        return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n            success: false,\n            message: authResult.message\n        }, {\n            status: authResult.status\n        });\n    }\n    try {\n        const movies = await _lib_models_movie__WEBPACK_IMPORTED_MODULE_2__[\"default\"].find({});\n        return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n            success: true,\n            data: movies\n        });\n    } catch (error) {\n        return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n            success: false,\n            error: error.message\n        }, {\n            status: 500\n        });\n    }\n}\nasync function POST(req) {\n    await connectDB();\n    const authResult = (0,_middleware_authenticateToken__WEBPACK_IMPORTED_MODULE_4__.authenticate)(req);\n    if (!authResult.success) {\n        return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n            success: false,\n            message: authResult.message\n        }, {\n            status: authResult.status\n        });\n    }\n    try {\n        const { title, publishingYear, posterURL } = await req.json();\n        if (!title || !publishingYear) {\n            return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n                success: false,\n                message: \"All fields are required\"\n            }, {\n                status: 400\n            });\n        }\n        const newMovie = new _lib_models_movie__WEBPACK_IMPORTED_MODULE_2__[\"default\"]({\n            title,\n            publishingYear,\n            posterURL\n        });\n        await newMovie.save();\n        return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n            success: true,\n            data: newMovie\n        }, {\n            status: 201\n        });\n    } catch (error) {\n        return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n            success: false,\n            error: error.message\n        }, {\n            status: 500\n        });\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2FwaS9tb3ZpZS9yb3V0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUNnRDtBQUNoQjtBQUNXO0FBQ0E7QUFDdUI7QUFFbEUsc0NBQXNDO0FBQ3RDLGVBQWVLO0lBQ2IsSUFBSUosNERBQW1CLENBQUNNLFVBQVUsS0FBSyxHQUFHO1FBQ3hDLE1BQU1OLHVEQUFnQixDQUFDRCxxREFBZ0JBO0lBQ3pDO0FBQ0Y7QUFHTyxlQUFlUyxJQUFJQyxHQUFHO0lBQzNCLE1BQU1MO0lBRU4sTUFBTU0sYUFBYVAsMkVBQVlBLENBQUNNO0lBQ2hDLElBQUksQ0FBQ0MsV0FBV0MsT0FBTyxFQUFFO1FBQ3ZCLE9BQU9ULHFEQUFZQSxDQUFDVSxJQUFJLENBQUM7WUFBRUQsU0FBUztZQUFPRSxTQUFTSCxXQUFXRyxPQUFPO1FBQUMsR0FBRztZQUFFQyxRQUFRSixXQUFXSSxNQUFNO1FBQUM7SUFDeEc7SUFFQSxJQUFJO1FBQ0YsTUFBTUMsU0FBUyxNQUFNZCx5REFBS0EsQ0FBQ2UsSUFBSSxDQUFDLENBQUM7UUFDakMsT0FBT2QscURBQVlBLENBQUNVLElBQUksQ0FBQztZQUFFRCxTQUFTO1lBQU1NLE1BQU1GO1FBQU87SUFDekQsRUFBRSxPQUFPRyxPQUFPO1FBQ2QsT0FBT2hCLHFEQUFZQSxDQUFDVSxJQUFJLENBQUM7WUFBRUQsU0FBUztZQUFPTyxPQUFPQSxNQUFNTCxPQUFPO1FBQUMsR0FBRztZQUFFQyxRQUFRO1FBQUk7SUFDbkY7QUFDRjtBQUdPLGVBQWVLLEtBQUtWLEdBQUc7SUFDNUIsTUFBTUw7SUFFTixNQUFNTSxhQUFhUCwyRUFBWUEsQ0FBQ007SUFDaEMsSUFBSSxDQUFDQyxXQUFXQyxPQUFPLEVBQUU7UUFDdkIsT0FBT1QscURBQVlBLENBQUNVLElBQUksQ0FBQztZQUFFRCxTQUFTO1lBQU9FLFNBQVNILFdBQVdHLE9BQU87UUFBQyxHQUFHO1lBQUVDLFFBQVFKLFdBQVdJLE1BQU07UUFBQztJQUN4RztJQUVBLElBQUk7UUFDRixNQUFNLEVBQUVNLEtBQUssRUFBRUMsY0FBYyxFQUFFQyxTQUFTLEVBQUUsR0FBRyxNQUFNYixJQUFJRyxJQUFJO1FBRTNELElBQUksQ0FBQ1EsU0FBUyxDQUFDQyxnQkFBZ0I7WUFDN0IsT0FBT25CLHFEQUFZQSxDQUFDVSxJQUFJLENBQUM7Z0JBQUVELFNBQVM7Z0JBQU9FLFNBQVM7WUFBMEIsR0FBRztnQkFBRUMsUUFBUTtZQUFJO1FBQ2pHO1FBRUEsTUFBTVMsV0FBVyxJQUFJdEIseURBQUtBLENBQUM7WUFBRW1CO1lBQU9DO1lBQWdCQztRQUFVO1FBQzlELE1BQU1DLFNBQVNDLElBQUk7UUFDbkIsT0FBT3RCLHFEQUFZQSxDQUFDVSxJQUFJLENBQUM7WUFBRUQsU0FBUztZQUFNTSxNQUFNTTtRQUFTLEdBQUc7WUFBRVQsUUFBUTtRQUFJO0lBQzVFLEVBQUUsT0FBT0ksT0FBTztRQUNkLE9BQU9oQixxREFBWUEsQ0FBQ1UsSUFBSSxDQUFDO1lBQUVELFNBQVM7WUFBT08sT0FBT0EsTUFBTUwsT0FBTztRQUFDLEdBQUc7WUFBRUMsUUFBUTtRQUFJO0lBQ25GO0FBQ0YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hc3NpZ25tZW50ZnVsbC8uL3NyYy9hcHAvYXBpL21vdmllL3JvdXRlLmpzPzIwMmQiXSwic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCB7IGNvbm5lY3Rpb25TdHJpbmcgfSBmcm9tIFwiLi4vLi4vbGliL2RiXCI7XHJcbmltcG9ydCBtb25nb29zZSBmcm9tIFwibW9uZ29vc2VcIjtcclxuaW1wb3J0IE1vdmllIGZyb20gJy4uLy4uL2xpYi9tb2RlbHMvbW92aWUnO1xyXG5pbXBvcnQgeyBOZXh0UmVzcG9uc2UgfSBmcm9tIFwibmV4dC9zZXJ2ZXJcIjtcclxuaW1wb3J0IHsgYXV0aGVudGljYXRlIH0gZnJvbSAnLi4vLi4vbWlkZGxld2FyZS9hdXRoZW50aWNhdGVUb2tlbic7IFxyXG5cclxuLy8gRnVuY3Rpb24gdG8gY29ubmVjdCB0byB0aGUgZGF0YWJhc2VcclxuYXN5bmMgZnVuY3Rpb24gY29ubmVjdERCKCkge1xyXG4gIGlmIChtb25nb29zZS5jb25uZWN0aW9uLnJlYWR5U3RhdGUgPT09IDApIHtcclxuICAgIGF3YWl0IG1vbmdvb3NlLmNvbm5lY3QoY29ubmVjdGlvblN0cmluZyk7XHJcbiAgfVxyXG59XHJcblxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIEdFVChyZXEpIHtcclxuICBhd2FpdCBjb25uZWN0REIoKTtcclxuXHJcbiAgY29uc3QgYXV0aFJlc3VsdCA9IGF1dGhlbnRpY2F0ZShyZXEpO1xyXG4gIGlmICghYXV0aFJlc3VsdC5zdWNjZXNzKSB7XHJcbiAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBzdWNjZXNzOiBmYWxzZSwgbWVzc2FnZTogYXV0aFJlc3VsdC5tZXNzYWdlIH0sIHsgc3RhdHVzOiBhdXRoUmVzdWx0LnN0YXR1cyB9KTtcclxuICB9XHJcblxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBtb3ZpZXMgPSBhd2FpdCBNb3ZpZS5maW5kKHt9KTtcclxuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IG1vdmllcyB9KTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBlcnJvci5tZXNzYWdlIH0sIHsgc3RhdHVzOiA1MDAgfSk7XHJcbiAgfVxyXG59XHJcblxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIFBPU1QocmVxKSB7XHJcbiAgYXdhaXQgY29ubmVjdERCKCk7XHJcblxyXG4gIGNvbnN0IGF1dGhSZXN1bHQgPSBhdXRoZW50aWNhdGUocmVxKTtcclxuICBpZiAoIWF1dGhSZXN1bHQuc3VjY2Vzcykge1xyXG4gICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgc3VjY2VzczogZmFsc2UsIG1lc3NhZ2U6IGF1dGhSZXN1bHQubWVzc2FnZSB9LCB7IHN0YXR1czogYXV0aFJlc3VsdC5zdGF0dXMgfSk7XHJcbiAgfVxyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgeyB0aXRsZSwgcHVibGlzaGluZ1llYXIsIHBvc3RlclVSTCB9ID0gYXdhaXQgcmVxLmpzb24oKTtcclxuXHJcbiAgICBpZiAoIXRpdGxlIHx8ICFwdWJsaXNoaW5nWWVhcikge1xyXG4gICAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBzdWNjZXNzOiBmYWxzZSwgbWVzc2FnZTogXCJBbGwgZmllbGRzIGFyZSByZXF1aXJlZFwiIH0sIHsgc3RhdHVzOiA0MDAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgbmV3TW92aWUgPSBuZXcgTW92aWUoeyB0aXRsZSwgcHVibGlzaGluZ1llYXIsIHBvc3RlclVSTCB9KTtcclxuICAgIGF3YWl0IG5ld01vdmllLnNhdmUoKTtcclxuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IG5ld01vdmllIH0sIHsgc3RhdHVzOiAyMDEgfSk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXJyb3IubWVzc2FnZSB9LCB7IHN0YXR1czogNTAwIH0pO1xyXG4gIH1cclxufVxyXG4iXSwibmFtZXMiOlsiY29ubmVjdGlvblN0cmluZyIsIm1vbmdvb3NlIiwiTW92aWUiLCJOZXh0UmVzcG9uc2UiLCJhdXRoZW50aWNhdGUiLCJjb25uZWN0REIiLCJjb25uZWN0aW9uIiwicmVhZHlTdGF0ZSIsImNvbm5lY3QiLCJHRVQiLCJyZXEiLCJhdXRoUmVzdWx0Iiwic3VjY2VzcyIsImpzb24iLCJtZXNzYWdlIiwic3RhdHVzIiwibW92aWVzIiwiZmluZCIsImRhdGEiLCJlcnJvciIsIlBPU1QiLCJ0aXRsZSIsInB1Ymxpc2hpbmdZZWFyIiwicG9zdGVyVVJMIiwibmV3TW92aWUiLCJzYXZlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./src/app/api/movie/route.js\n");

/***/ }),

/***/ "(rsc)/./src/app/lib/db.js":
/*!***************************!*\
  !*** ./src/app/lib/db.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   connectionString: () => (/* binding */ connectionString)\n/* harmony export */ });\nconst connectionString = \"mongodb+srv://sahilthakurautviz:7H8s6qWCoR73Jl10@cluster0.ekkcc.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0\";\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2xpYi9kYi5qcyIsIm1hcHBpbmdzIjoiOzs7O0FBQU8sTUFBTUEsbUJBQWtCLDRIQUEySCIsInNvdXJjZXMiOlsid2VicGFjazovL2Fzc2lnbm1lbnRmdWxsLy4vc3JjL2FwcC9saWIvZGIuanM/MTQ3ZCJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgY29ubmVjdGlvblN0cmluZyA9XCJtb25nb2RiK3NydjovL3NhaGlsdGhha3VyYXV0dml6OjdIOHM2cVdDb1I3M0psMTBAY2x1c3RlcjAuZWtrY2MubW9uZ29kYi5uZXQvP3JldHJ5V3JpdGVzPXRydWUmdz1tYWpvcml0eSZhcHBOYW1lPUNsdXN0ZXIwXCJcclxuIl0sIm5hbWVzIjpbImNvbm5lY3Rpb25TdHJpbmciXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./src/app/lib/db.js\n");

/***/ }),

/***/ "(rsc)/./src/app/lib/models/movie.js":
/*!*************************************!*\
  !*** ./src/app/lib/models/movie.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n// models/Movie.js\n\nconst MovieSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({\n    title: {\n        type: String,\n        required: true\n    },\n    publishingYear: {\n        type: Number,\n        required: true\n    },\n    posterURL: {\n        type: String,\n        required: true\n    }\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models).Movie || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Movie', MovieSchema));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2xpYi9tb2RlbHMvbW92aWUuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsa0JBQWtCO0FBQ2M7QUFFaEMsTUFBTUMsY0FBYyxJQUFJRCx3REFBZSxDQUFDO0lBQ3RDRyxPQUFPO1FBQUVDLE1BQU1DO1FBQVFDLFVBQVU7SUFBSztJQUN0Q0MsZ0JBQWdCO1FBQUVILE1BQU1JO1FBQVFGLFVBQVU7SUFBSztJQUMvQ0csV0FBVztRQUFFTCxNQUFNQztRQUFRQyxVQUFVO0lBQUs7QUFDNUM7QUFFQSxpRUFBZU4sd0RBQWUsQ0FBQ1csS0FBSyxJQUFJWCxxREFBYyxDQUFDLFNBQVNDLFlBQVlBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hc3NpZ25tZW50ZnVsbC8uL3NyYy9hcHAvbGliL21vZGVscy9tb3ZpZS5qcz9lZDdhIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIG1vZGVscy9Nb3ZpZS5qc1xyXG5pbXBvcnQgbW9uZ29vc2UgZnJvbSAnbW9uZ29vc2UnO1xyXG5cclxuY29uc3QgTW92aWVTY2hlbWEgPSBuZXcgbW9uZ29vc2UuU2NoZW1hKHtcclxuICB0aXRsZTogeyB0eXBlOiBTdHJpbmcsIHJlcXVpcmVkOiB0cnVlIH0sXHJcbiAgcHVibGlzaGluZ1llYXI6IHsgdHlwZTogTnVtYmVyLCByZXF1aXJlZDogdHJ1ZSB9LFxyXG4gIHBvc3RlclVSTDogeyB0eXBlOiBTdHJpbmcsIHJlcXVpcmVkOiB0cnVlIH0sXHJcbn0pO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgbW9uZ29vc2UubW9kZWxzLk1vdmllIHx8IG1vbmdvb3NlLm1vZGVsKCdNb3ZpZScsIE1vdmllU2NoZW1hKTtcclxuIl0sIm5hbWVzIjpbIm1vbmdvb3NlIiwiTW92aWVTY2hlbWEiLCJTY2hlbWEiLCJ0aXRsZSIsInR5cGUiLCJTdHJpbmciLCJyZXF1aXJlZCIsInB1Ymxpc2hpbmdZZWFyIiwiTnVtYmVyIiwicG9zdGVyVVJMIiwibW9kZWxzIiwiTW92aWUiLCJtb2RlbCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./src/app/lib/models/movie.js\n");

/***/ }),

/***/ "(rsc)/./src/app/middleware/authenticateToken.js":
/*!*************************************************!*\
  !*** ./src/app/middleware/authenticateToken.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   authenticate: () => (/* binding */ authenticate)\n/* harmony export */ });\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jsonwebtoken */ \"(rsc)/./node_modules/jsonwebtoken/index.js\");\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n\n\nfunction authenticate(req) {\n    const token = req.headers.get('Authorization')?.split(' ')[1];\n    if (!token) {\n        return {\n            success: false,\n            message: 'Authentication required',\n            status: 401\n        };\n    }\n    try {\n        const decoded = jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default().verify(token, \"wANfQv8JNbvgjwgV\");\n        req.user = decoded;\n        return {\n            success: true\n        };\n    } catch (error) {\n        return {\n            success: false,\n            message: 'Invalid token',\n            status: 403\n        };\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL21pZGRsZXdhcmUvYXV0aGVudGljYXRlVG9rZW4uanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUMrQjtBQUNZO0FBR3BDLFNBQVNFLGFBQWFDLEdBQUc7SUFFOUIsTUFBTUMsUUFBUUQsSUFBSUUsT0FBTyxDQUFDQyxHQUFHLENBQUMsa0JBQWtCQyxNQUFNLElBQUksQ0FBQyxFQUFFO0lBRzdELElBQUksQ0FBQ0gsT0FBTztRQUNWLE9BQU87WUFBRUksU0FBUztZQUFPQyxTQUFTO1lBQTJCQyxRQUFRO1FBQUk7SUFDM0U7SUFFQSxJQUFJO1FBRUYsTUFBTUMsVUFBVVgsMERBQVUsQ0FBQ0ksT0FBTztRQUNsQ0QsSUFBSVUsSUFBSSxHQUFHRjtRQUNYLE9BQU87WUFBRUgsU0FBUztRQUFLO0lBQ3pCLEVBQUUsT0FBT00sT0FBTztRQUNkLE9BQU87WUFBRU4sU0FBUztZQUFPQyxTQUFTO1lBQWlCQyxRQUFRO1FBQUk7SUFDakU7QUFDRiIsInNvdXJjZXMiOlsid2VicGFjazovL2Fzc2lnbm1lbnRmdWxsLy4vc3JjL2FwcC9taWRkbGV3YXJlL2F1dGhlbnRpY2F0ZVRva2VuLmpzPzQwOGYiXSwic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCBqd3QgZnJvbSAnanNvbndlYnRva2VuJztcclxuaW1wb3J0IHsgTmV4dFJlc3BvbnNlIH0gZnJvbSAnbmV4dC9zZXJ2ZXInO1xyXG5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhdXRoZW50aWNhdGUocmVxKSB7XHJcblxyXG4gIGNvbnN0IHRva2VuID0gcmVxLmhlYWRlcnMuZ2V0KCdBdXRob3JpemF0aW9uJyk/LnNwbGl0KCcgJylbMV07XHJcblxyXG5cclxuICBpZiAoIXRva2VuKSB7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgbWVzc2FnZTogJ0F1dGhlbnRpY2F0aW9uIHJlcXVpcmVkJywgc3RhdHVzOiA0MDEgfTtcclxuICB9XHJcblxyXG4gIHRyeSB7XHJcbiBcclxuICAgIGNvbnN0IGRlY29kZWQgPSBqd3QudmVyaWZ5KHRva2VuLCBcIndBTmZRdjhKTmJ2Z2p3Z1ZcIik7XHJcbiAgICByZXEudXNlciA9IGRlY29kZWQ7IFxyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9OyBcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIG1lc3NhZ2U6ICdJbnZhbGlkIHRva2VuJywgc3RhdHVzOiA0MDMgfTtcclxuICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbImp3dCIsIk5leHRSZXNwb25zZSIsImF1dGhlbnRpY2F0ZSIsInJlcSIsInRva2VuIiwiaGVhZGVycyIsImdldCIsInNwbGl0Iiwic3VjY2VzcyIsIm1lc3NhZ2UiLCJzdGF0dXMiLCJkZWNvZGVkIiwidmVyaWZ5IiwidXNlciIsImVycm9yIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./src/app/middleware/authenticateToken.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/ms","vendor-chunks/semver","vendor-chunks/jsonwebtoken","vendor-chunks/jws","vendor-chunks/ecdsa-sig-formatter","vendor-chunks/safe-buffer","vendor-chunks/lodash.once","vendor-chunks/lodash.isstring","vendor-chunks/lodash.isplainobject","vendor-chunks/lodash.isnumber","vendor-chunks/lodash.isinteger","vendor-chunks/lodash.isboolean","vendor-chunks/lodash.includes","vendor-chunks/jwa","vendor-chunks/buffer-equal-constant-time"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fmovie%2Froute&page=%2Fapi%2Fmovie%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fmovie%2Froute.js&appDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();