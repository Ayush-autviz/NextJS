/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/movie/[movieId]/route";
exports.ids = ["app/api/movie/[movieId]/route"];
exports.modules = {

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("mongoose");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "../app-render/work-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/server/app-render/work-async-storage.external.js" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ "./work-unit-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist/server/app-render/work-unit-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fmovie%2F%5BmovieId%5D%2Froute&page=%2Fapi%2Fmovie%2F%5BmovieId%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fmovie%2F%5BmovieId%5D%2Froute.js&appDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fmovie%2F%5BmovieId%5D%2Froute&page=%2Fapi%2Fmovie%2F%5BmovieId%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fmovie%2F%5BmovieId%5D%2Froute.js&appDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),\n/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(rsc)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var C_Users_lenovo_Downloads_zip_2_src_app_api_movie_movieId_route_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/app/api/movie/[movieId]/route.js */ \"(rsc)/./src/app/api/movie/[movieId]/route.js\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/movie/[movieId]/route\",\n        pathname: \"/api/movie/[movieId]\",\n        filename: \"route\",\n        bundlePath: \"app/api/movie/[movieId]/route\"\n    },\n    resolvedPagePath: \"C:\\\\Users\\\\lenovo\\\\Downloads\\\\zip 2\\\\src\\\\app\\\\api\\\\movie\\\\[movieId]\\\\route.js\",\n    nextConfigOutput,\n    userland: C_Users_lenovo_Downloads_zip_2_src_app_api_movie_movieId_route_js__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        workAsyncStorage,\n        workUnitAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIvaW5kZXguanM/bmFtZT1hcHAlMkZhcGklMkZtb3ZpZSUyRiU1Qm1vdmllSWQlNUQlMkZyb3V0ZSZwYWdlPSUyRmFwaSUyRm1vdmllJTJGJTVCbW92aWVJZCU1RCUyRnJvdXRlJmFwcFBhdGhzPSZwYWdlUGF0aD1wcml2YXRlLW5leHQtYXBwLWRpciUyRmFwaSUyRm1vdmllJTJGJTVCbW92aWVJZCU1RCUyRnJvdXRlLmpzJmFwcERpcj1DJTNBJTVDVXNlcnMlNUNsZW5vdm8lNUNEb3dubG9hZHMlNUN6aXAlMjAyJTVDc3JjJTVDYXBwJnBhZ2VFeHRlbnNpb25zPXRzeCZwYWdlRXh0ZW5zaW9ucz10cyZwYWdlRXh0ZW5zaW9ucz1qc3gmcGFnZUV4dGVuc2lvbnM9anMmcm9vdERpcj1DJTNBJTVDVXNlcnMlNUNsZW5vdm8lNUNEb3dubG9hZHMlNUN6aXAlMjAyJmlzRGV2PXRydWUmdHNjb25maWdQYXRoPXRzY29uZmlnLmpzb24mYmFzZVBhdGg9JmFzc2V0UHJlZml4PSZuZXh0Q29uZmlnT3V0cHV0PSZwcmVmZXJyZWRSZWdpb249Jm1pZGRsZXdhcmVDb25maWc9ZTMwJTNEISIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUErRjtBQUN2QztBQUNxQjtBQUM4QjtBQUMzRztBQUNBO0FBQ0E7QUFDQSx3QkFBd0IseUdBQW1CO0FBQzNDO0FBQ0EsY0FBYyxrRUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsWUFBWTtBQUNaLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxRQUFRLHNEQUFzRDtBQUM5RDtBQUNBLFdBQVcsNEVBQVc7QUFDdEI7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUMwRjs7QUFFMUYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hc3NpZ25tZW50ZnVsbC8/M2I4ZiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcHBSb3V0ZVJvdXRlTW9kdWxlIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvcm91dGUtbW9kdWxlcy9hcHAtcm91dGUvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1raW5kXCI7XG5pbXBvcnQgeyBwYXRjaEZldGNoIGFzIF9wYXRjaEZldGNoIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvbGliL3BhdGNoLWZldGNoXCI7XG5pbXBvcnQgKiBhcyB1c2VybGFuZCBmcm9tIFwiQzpcXFxcVXNlcnNcXFxcbGVub3ZvXFxcXERvd25sb2Fkc1xcXFx6aXAgMlxcXFxzcmNcXFxcYXBwXFxcXGFwaVxcXFxtb3ZpZVxcXFxbbW92aWVJZF1cXFxccm91dGUuanNcIjtcbi8vIFdlIGluamVjdCB0aGUgbmV4dENvbmZpZ091dHB1dCBoZXJlIHNvIHRoYXQgd2UgY2FuIHVzZSB0aGVtIGluIHRoZSByb3V0ZVxuLy8gbW9kdWxlLlxuY29uc3QgbmV4dENvbmZpZ091dHB1dCA9IFwiXCJcbmNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IEFwcFJvdXRlUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLkFQUF9ST1VURSxcbiAgICAgICAgcGFnZTogXCIvYXBpL21vdmllL1ttb3ZpZUlkXS9yb3V0ZVwiLFxuICAgICAgICBwYXRobmFtZTogXCIvYXBpL21vdmllL1ttb3ZpZUlkXVwiLFxuICAgICAgICBmaWxlbmFtZTogXCJyb3V0ZVwiLFxuICAgICAgICBidW5kbGVQYXRoOiBcImFwcC9hcGkvbW92aWUvW21vdmllSWRdL3JvdXRlXCJcbiAgICB9LFxuICAgIHJlc29sdmVkUGFnZVBhdGg6IFwiQzpcXFxcVXNlcnNcXFxcbGVub3ZvXFxcXERvd25sb2Fkc1xcXFx6aXAgMlxcXFxzcmNcXFxcYXBwXFxcXGFwaVxcXFxtb3ZpZVxcXFxbbW92aWVJZF1cXFxccm91dGUuanNcIixcbiAgICBuZXh0Q29uZmlnT3V0cHV0LFxuICAgIHVzZXJsYW5kXG59KTtcbi8vIFB1bGwgb3V0IHRoZSBleHBvcnRzIHRoYXQgd2UgbmVlZCB0byBleHBvc2UgZnJvbSB0aGUgbW9kdWxlLiBUaGlzIHNob3VsZFxuLy8gYmUgZWxpbWluYXRlZCB3aGVuIHdlJ3ZlIG1vdmVkIHRoZSBvdGhlciByb3V0ZXMgdG8gdGhlIG5ldyBmb3JtYXQuIFRoZXNlXG4vLyBhcmUgdXNlZCB0byBob29rIGludG8gdGhlIHJvdXRlLlxuY29uc3QgeyB3b3JrQXN5bmNTdG9yYWdlLCB3b3JrVW5pdEFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MgfSA9IHJvdXRlTW9kdWxlO1xuZnVuY3Rpb24gcGF0Y2hGZXRjaCgpIHtcbiAgICByZXR1cm4gX3BhdGNoRmV0Y2goe1xuICAgICAgICB3b3JrQXN5bmNTdG9yYWdlLFxuICAgICAgICB3b3JrVW5pdEFzeW5jU3RvcmFnZVxuICAgIH0pO1xufVxuZXhwb3J0IHsgcm91dGVNb2R1bGUsIHdvcmtBc3luY1N0b3JhZ2UsIHdvcmtVbml0QXN5bmNTdG9yYWdlLCBzZXJ2ZXJIb29rcywgcGF0Y2hGZXRjaCwgIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFwcC1yb3V0ZS5qcy5tYXAiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fmovie%2F%5BmovieId%5D%2Froute&page=%2Fapi%2Fmovie%2F%5BmovieId%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fmovie%2F%5BmovieId%5D%2Froute.js&appDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(rsc)/./src/app/api/movie/[movieId]/route.js":
/*!**********************************************!*\
  !*** ./src/app/api/movie/[movieId]/route.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ GET),\n/* harmony export */   PUT: () => (/* binding */ PUT)\n/* harmony export */ });\n/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../lib/db */ \"(rsc)/./src/app/lib/db.js\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _lib_models_movie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../lib/models/movie */ \"(rsc)/./src/app/lib/models/movie.js\");\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n/* harmony import */ var _middleware_authenticateToken__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../middleware/authenticateToken */ \"(rsc)/./src/app/middleware/authenticateToken.js\");\n// src/app/api/movie/[movieId]/route.js\n\n\n\n\n\nasync function connectDB() {\n    if ((mongoose__WEBPACK_IMPORTED_MODULE_1___default().connection).readyState === 0) {\n        await mongoose__WEBPACK_IMPORTED_MODULE_1___default().connect(_lib_db__WEBPACK_IMPORTED_MODULE_0__.connectionString);\n    }\n}\nasync function GET(req, { params }) {\n    await connectDB();\n    const authResult = (0,_middleware_authenticateToken__WEBPACK_IMPORTED_MODULE_4__.authenticate)(req);\n    if (!authResult.success) {\n        return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n            success: false,\n            message: authResult.message\n        }, {\n            status: authResult.status\n        });\n    }\n    try {\n        const { movieId } = params;\n        const movie = await _lib_models_movie__WEBPACK_IMPORTED_MODULE_2__[\"default\"].findById(movieId);\n        if (!movie) {\n            return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n                success: false,\n                message: \"Movie not found\"\n            }, {\n                status: 404\n            });\n        }\n        return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n            success: true,\n            data: movie\n        });\n    } catch (error) {\n        return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n            success: false,\n            error: error.message\n        }, {\n            status: 500\n        });\n    }\n}\nasync function PUT(req, { params }) {\n    await connectDB();\n    const authResult = (0,_middleware_authenticateToken__WEBPACK_IMPORTED_MODULE_4__.authenticate)(req);\n    if (!authResult.success) {\n        return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n            success: false,\n            message: authResult.message\n        }, {\n            status: authResult.status\n        });\n    }\n    try {\n        const { movieId } = params;\n        const { title, publishingYear, posterURL } = await req.json();\n        if (!title && !publishingYear && !posterURL) {\n            return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n                success: false,\n                message: \"At least one field must be provided for update\"\n            }, {\n                status: 400\n            });\n        }\n        const updateData = {};\n        if (title) updateData.title = title;\n        if (publishingYear) updateData.publishingYear = publishingYear;\n        if (posterURL) updateData.posterURL = posterURL;\n        const updatedMovie = await _lib_models_movie__WEBPACK_IMPORTED_MODULE_2__[\"default\"].findByIdAndUpdate(movieId, updateData, {\n            new: true\n        }); // Update the movie\n        if (!updatedMovie) {\n            return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n                success: false,\n                message: \"Movie not found\"\n            }, {\n                status: 404\n            });\n        }\n        return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n            success: true,\n            data: updatedMovie\n        });\n    } catch (error) {\n        return next_server__WEBPACK_IMPORTED_MODULE_3__.NextResponse.json({\n            success: false,\n            error: error.message\n        }, {\n            status: 500\n        });\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2FwaS9tb3ZpZS9bbW92aWVJZF0vcm91dGUuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQSx1Q0FBdUM7QUFDWTtBQUNuQjtBQUNjO0FBQ0g7QUFDMEI7QUFFckUsZUFBZUs7SUFDYixJQUFJSiw0REFBbUIsQ0FBQ00sVUFBVSxLQUFLLEdBQUc7UUFDeEMsTUFBTU4sdURBQWdCLENBQUNELHFEQUFnQkE7SUFDekM7QUFDRjtBQUVPLGVBQWVTLElBQUlDLEdBQUcsRUFBRSxFQUFFQyxNQUFNLEVBQUU7SUFDdkMsTUFBTU47SUFFTixNQUFNTyxhQUFhUiwyRUFBWUEsQ0FBQ007SUFDaEMsSUFBSSxDQUFDRSxXQUFXQyxPQUFPLEVBQUU7UUFDdkIsT0FBT1YscURBQVlBLENBQUNXLElBQUksQ0FBQztZQUFFRCxTQUFTO1lBQU9FLFNBQVNILFdBQVdHLE9BQU87UUFBQyxHQUFHO1lBQUVDLFFBQVFKLFdBQVdJLE1BQU07UUFBQztJQUN4RztJQUVBLElBQUk7UUFDRixNQUFNLEVBQUVDLE9BQU8sRUFBRSxHQUFHTjtRQUNwQixNQUFNTyxRQUFRLE1BQU1oQix5REFBS0EsQ0FBQ2lCLFFBQVEsQ0FBQ0Y7UUFFbkMsSUFBSSxDQUFDQyxPQUFPO1lBQ1YsT0FBT2YscURBQVlBLENBQUNXLElBQUksQ0FBQztnQkFBRUQsU0FBUztnQkFBT0UsU0FBUztZQUFrQixHQUFHO2dCQUFFQyxRQUFRO1lBQUk7UUFDekY7UUFFQSxPQUFPYixxREFBWUEsQ0FBQ1csSUFBSSxDQUFDO1lBQUVELFNBQVM7WUFBTU8sTUFBTUY7UUFBTTtJQUN4RCxFQUFFLE9BQU9HLE9BQU87UUFDZCxPQUFPbEIscURBQVlBLENBQUNXLElBQUksQ0FBQztZQUFFRCxTQUFTO1lBQU9RLE9BQU9BLE1BQU1OLE9BQU87UUFBQyxHQUFHO1lBQUVDLFFBQVE7UUFBSTtJQUNuRjtBQUNGO0FBR08sZUFBZU0sSUFBSVosR0FBRyxFQUFFLEVBQUVDLE1BQU0sRUFBRTtJQUN2QyxNQUFNTjtJQUVOLE1BQU1PLGFBQWFSLDJFQUFZQSxDQUFDTTtJQUNoQyxJQUFJLENBQUNFLFdBQVdDLE9BQU8sRUFBRTtRQUN2QixPQUFPVixxREFBWUEsQ0FBQ1csSUFBSSxDQUFDO1lBQUVELFNBQVM7WUFBT0UsU0FBU0gsV0FBV0csT0FBTztRQUFDLEdBQUc7WUFBRUMsUUFBUUosV0FBV0ksTUFBTTtRQUFDO0lBQ3hHO0lBRUEsSUFBSTtRQUNGLE1BQU0sRUFBRUMsT0FBTyxFQUFFLEdBQUdOO1FBQ3BCLE1BQU0sRUFBRVksS0FBSyxFQUFFQyxjQUFjLEVBQUVDLFNBQVMsRUFBRSxHQUFHLE1BQU1mLElBQUlJLElBQUk7UUFFM0QsSUFBSSxDQUFDUyxTQUFTLENBQUNDLGtCQUFrQixDQUFDQyxXQUFXO1lBQzNDLE9BQU90QixxREFBWUEsQ0FBQ1csSUFBSSxDQUFDO2dCQUFFRCxTQUFTO2dCQUFPRSxTQUFTO1lBQWlELEdBQUc7Z0JBQUVDLFFBQVE7WUFBSTtRQUN4SDtRQUdBLE1BQU1VLGFBQWEsQ0FBQztRQUNwQixJQUFJSCxPQUFPRyxXQUFXSCxLQUFLLEdBQUdBO1FBQzlCLElBQUlDLGdCQUFnQkUsV0FBV0YsY0FBYyxHQUFHQTtRQUNoRCxJQUFJQyxXQUFXQyxXQUFXRCxTQUFTLEdBQUdBO1FBRXRDLE1BQU1FLGVBQWUsTUFBTXpCLHlEQUFLQSxDQUFDMEIsaUJBQWlCLENBQUNYLFNBQVNTLFlBQVk7WUFBRUcsS0FBSztRQUFLLElBQUksbUJBQW1CO1FBRTNHLElBQUksQ0FBQ0YsY0FBYztZQUNqQixPQUFPeEIscURBQVlBLENBQUNXLElBQUksQ0FBQztnQkFBRUQsU0FBUztnQkFBT0UsU0FBUztZQUFrQixHQUFHO2dCQUFFQyxRQUFRO1lBQUk7UUFDekY7UUFFQSxPQUFPYixxREFBWUEsQ0FBQ1csSUFBSSxDQUFDO1lBQUVELFNBQVM7WUFBTU8sTUFBTU87UUFBYTtJQUMvRCxFQUFFLE9BQU9OLE9BQU87UUFDZCxPQUFPbEIscURBQVlBLENBQUNXLElBQUksQ0FBQztZQUFFRCxTQUFTO1lBQU9RLE9BQU9BLE1BQU1OLE9BQU87UUFBQyxHQUFHO1lBQUVDLFFBQVE7UUFBSTtJQUNuRjtBQUNGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYXNzaWdubWVudGZ1bGwvLi9zcmMvYXBwL2FwaS9tb3ZpZS9bbW92aWVJZF0vcm91dGUuanM/MTA3YyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzcmMvYXBwL2FwaS9tb3ZpZS9bbW92aWVJZF0vcm91dGUuanNcclxuaW1wb3J0IHsgY29ubmVjdGlvblN0cmluZyB9IGZyb20gXCIuLi8uLi8uLi9saWIvZGJcIjtcclxuaW1wb3J0IG1vbmdvb3NlIGZyb20gXCJtb25nb29zZVwiO1xyXG5pbXBvcnQgTW92aWUgZnJvbSAnLi4vLi4vLi4vbGliL21vZGVscy9tb3ZpZSc7XHJcbmltcG9ydCB7IE5leHRSZXNwb25zZSB9IGZyb20gXCJuZXh0L3NlcnZlclwiO1xyXG5pbXBvcnQgeyBhdXRoZW50aWNhdGUgfSBmcm9tICcuLi8uLi8uLi9taWRkbGV3YXJlL2F1dGhlbnRpY2F0ZVRva2VuJzsgXHJcblxyXG5hc3luYyBmdW5jdGlvbiBjb25uZWN0REIoKSB7XHJcbiAgaWYgKG1vbmdvb3NlLmNvbm5lY3Rpb24ucmVhZHlTdGF0ZSA9PT0gMCkge1xyXG4gICAgYXdhaXQgbW9uZ29vc2UuY29ubmVjdChjb25uZWN0aW9uU3RyaW5nKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBHRVQocmVxLCB7IHBhcmFtcyB9KSB7XHJcbiAgYXdhaXQgY29ubmVjdERCKCk7XHJcblxyXG4gIGNvbnN0IGF1dGhSZXN1bHQgPSBhdXRoZW50aWNhdGUocmVxKTtcclxuICBpZiAoIWF1dGhSZXN1bHQuc3VjY2Vzcykge1xyXG4gICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgc3VjY2VzczogZmFsc2UsIG1lc3NhZ2U6IGF1dGhSZXN1bHQubWVzc2FnZSB9LCB7IHN0YXR1czogYXV0aFJlc3VsdC5zdGF0dXMgfSk7XHJcbiAgfVxyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgeyBtb3ZpZUlkIH0gPSBwYXJhbXM7IFxyXG4gICAgY29uc3QgbW92aWUgPSBhd2FpdCBNb3ZpZS5maW5kQnlJZChtb3ZpZUlkKTsgXHJcblxyXG4gICAgaWYgKCFtb3ZpZSkge1xyXG4gICAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBzdWNjZXNzOiBmYWxzZSwgbWVzc2FnZTogXCJNb3ZpZSBub3QgZm91bmRcIiB9LCB7IHN0YXR1czogNDA0IH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IG1vdmllIH0pO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfSwgeyBzdGF0dXM6IDUwMCB9KTtcclxuICB9XHJcbn1cclxuXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gUFVUKHJlcSwgeyBwYXJhbXMgfSkge1xyXG4gIGF3YWl0IGNvbm5lY3REQigpO1xyXG5cclxuICBjb25zdCBhdXRoUmVzdWx0ID0gYXV0aGVudGljYXRlKHJlcSk7XHJcbiAgaWYgKCFhdXRoUmVzdWx0LnN1Y2Nlc3MpIHtcclxuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IHN1Y2Nlc3M6IGZhbHNlLCBtZXNzYWdlOiBhdXRoUmVzdWx0Lm1lc3NhZ2UgfSwgeyBzdGF0dXM6IGF1dGhSZXN1bHQuc3RhdHVzIH0pO1xyXG4gIH1cclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHsgbW92aWVJZCB9ID0gcGFyYW1zOyBcclxuICAgIGNvbnN0IHsgdGl0bGUsIHB1Ymxpc2hpbmdZZWFyLCBwb3N0ZXJVUkwgfSA9IGF3YWl0IHJlcS5qc29uKCk7IFxyXG5cclxuICAgIGlmICghdGl0bGUgJiYgIXB1Ymxpc2hpbmdZZWFyICYmICFwb3N0ZXJVUkwpIHtcclxuICAgICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgc3VjY2VzczogZmFsc2UsIG1lc3NhZ2U6IFwiQXQgbGVhc3Qgb25lIGZpZWxkIG11c3QgYmUgcHJvdmlkZWQgZm9yIHVwZGF0ZVwiIH0sIHsgc3RhdHVzOiA0MDAgfSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIGNvbnN0IHVwZGF0ZURhdGEgPSB7fTtcclxuICAgIGlmICh0aXRsZSkgdXBkYXRlRGF0YS50aXRsZSA9IHRpdGxlO1xyXG4gICAgaWYgKHB1Ymxpc2hpbmdZZWFyKSB1cGRhdGVEYXRhLnB1Ymxpc2hpbmdZZWFyID0gcHVibGlzaGluZ1llYXI7XHJcbiAgICBpZiAocG9zdGVyVVJMKSB1cGRhdGVEYXRhLnBvc3RlclVSTCA9IHBvc3RlclVSTDtcclxuXHJcbiAgICBjb25zdCB1cGRhdGVkTW92aWUgPSBhd2FpdCBNb3ZpZS5maW5kQnlJZEFuZFVwZGF0ZShtb3ZpZUlkLCB1cGRhdGVEYXRhLCB7IG5ldzogdHJ1ZSB9KTsgLy8gVXBkYXRlIHRoZSBtb3ZpZVxyXG5cclxuICAgIGlmICghdXBkYXRlZE1vdmllKSB7XHJcbiAgICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IHN1Y2Nlc3M6IGZhbHNlLCBtZXNzYWdlOiBcIk1vdmllIG5vdCBmb3VuZFwiIH0sIHsgc3RhdHVzOiA0MDQgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgc3VjY2VzczogdHJ1ZSwgZGF0YTogdXBkYXRlZE1vdmllIH0pO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfSwgeyBzdGF0dXM6IDUwMCB9KTtcclxuICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbImNvbm5lY3Rpb25TdHJpbmciLCJtb25nb29zZSIsIk1vdmllIiwiTmV4dFJlc3BvbnNlIiwiYXV0aGVudGljYXRlIiwiY29ubmVjdERCIiwiY29ubmVjdGlvbiIsInJlYWR5U3RhdGUiLCJjb25uZWN0IiwiR0VUIiwicmVxIiwicGFyYW1zIiwiYXV0aFJlc3VsdCIsInN1Y2Nlc3MiLCJqc29uIiwibWVzc2FnZSIsInN0YXR1cyIsIm1vdmllSWQiLCJtb3ZpZSIsImZpbmRCeUlkIiwiZGF0YSIsImVycm9yIiwiUFVUIiwidGl0bGUiLCJwdWJsaXNoaW5nWWVhciIsInBvc3RlclVSTCIsInVwZGF0ZURhdGEiLCJ1cGRhdGVkTW92aWUiLCJmaW5kQnlJZEFuZFVwZGF0ZSIsIm5ldyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./src/app/api/movie/[movieId]/route.js\n");

/***/ }),

/***/ "(rsc)/./src/app/lib/db.js":
/*!***************************!*\
  !*** ./src/app/lib/db.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   connectionString: () => (/* binding */ connectionString)\n/* harmony export */ });\nconst connectionString = \"mongodb+srv://sahilthakurautviz:7H8s6qWCoR73Jl10@cluster0.ekkcc.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0\";\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2xpYi9kYi5qcyIsIm1hcHBpbmdzIjoiOzs7O0FBQU8sTUFBTUEsbUJBQWtCLDRIQUEySCIsInNvdXJjZXMiOlsid2VicGFjazovL2Fzc2lnbm1lbnRmdWxsLy4vc3JjL2FwcC9saWIvZGIuanM/MTQ3ZCJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgY29ubmVjdGlvblN0cmluZyA9XCJtb25nb2RiK3NydjovL3NhaGlsdGhha3VyYXV0dml6OjdIOHM2cVdDb1I3M0psMTBAY2x1c3RlcjAuZWtrY2MubW9uZ29kYi5uZXQvP3JldHJ5V3JpdGVzPXRydWUmdz1tYWpvcml0eSZhcHBOYW1lPUNsdXN0ZXIwXCJcclxuIl0sIm5hbWVzIjpbImNvbm5lY3Rpb25TdHJpbmciXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./src/app/lib/db.js\n");

/***/ }),

/***/ "(rsc)/./src/app/lib/models/movie.js":
/*!*************************************!*\
  !*** ./src/app/lib/models/movie.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n// models/Movie.js\n\nconst MovieSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({\n    title: {\n        type: String,\n        required: true\n    },\n    publishingYear: {\n        type: Number,\n        required: true\n    },\n    posterURL: {\n        type: String,\n        required: true\n    }\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models).Movie || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Movie', MovieSchema));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2xpYi9tb2RlbHMvbW92aWUuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsa0JBQWtCO0FBQ2M7QUFFaEMsTUFBTUMsY0FBYyxJQUFJRCx3REFBZSxDQUFDO0lBQ3RDRyxPQUFPO1FBQUVDLE1BQU1DO1FBQVFDLFVBQVU7SUFBSztJQUN0Q0MsZ0JBQWdCO1FBQUVILE1BQU1JO1FBQVFGLFVBQVU7SUFBSztJQUMvQ0csV0FBVztRQUFFTCxNQUFNQztRQUFRQyxVQUFVO0lBQUs7QUFDNUM7QUFFQSxpRUFBZU4sd0RBQWUsQ0FBQ1csS0FBSyxJQUFJWCxxREFBYyxDQUFDLFNBQVNDLFlBQVlBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hc3NpZ25tZW50ZnVsbC8uL3NyYy9hcHAvbGliL21vZGVscy9tb3ZpZS5qcz9lZDdhIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIG1vZGVscy9Nb3ZpZS5qc1xyXG5pbXBvcnQgbW9uZ29vc2UgZnJvbSAnbW9uZ29vc2UnO1xyXG5cclxuY29uc3QgTW92aWVTY2hlbWEgPSBuZXcgbW9uZ29vc2UuU2NoZW1hKHtcclxuICB0aXRsZTogeyB0eXBlOiBTdHJpbmcsIHJlcXVpcmVkOiB0cnVlIH0sXHJcbiAgcHVibGlzaGluZ1llYXI6IHsgdHlwZTogTnVtYmVyLCByZXF1aXJlZDogdHJ1ZSB9LFxyXG4gIHBvc3RlclVSTDogeyB0eXBlOiBTdHJpbmcsIHJlcXVpcmVkOiB0cnVlIH0sXHJcbn0pO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgbW9uZ29vc2UubW9kZWxzLk1vdmllIHx8IG1vbmdvb3NlLm1vZGVsKCdNb3ZpZScsIE1vdmllU2NoZW1hKTtcclxuIl0sIm5hbWVzIjpbIm1vbmdvb3NlIiwiTW92aWVTY2hlbWEiLCJTY2hlbWEiLCJ0aXRsZSIsInR5cGUiLCJTdHJpbmciLCJyZXF1aXJlZCIsInB1Ymxpc2hpbmdZZWFyIiwiTnVtYmVyIiwicG9zdGVyVVJMIiwibW9kZWxzIiwiTW92aWUiLCJtb2RlbCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./src/app/lib/models/movie.js\n");

/***/ }),

/***/ "(rsc)/./src/app/middleware/authenticateToken.js":
/*!*************************************************!*\
  !*** ./src/app/middleware/authenticateToken.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   authenticate: () => (/* binding */ authenticate)\n/* harmony export */ });\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jsonwebtoken */ \"(rsc)/./node_modules/jsonwebtoken/index.js\");\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n\n\nfunction authenticate(req) {\n    const token = req.headers.get('Authorization')?.split(' ')[1];\n    if (!token) {\n        return {\n            success: false,\n            message: 'Authentication required',\n            status: 401\n        };\n    }\n    try {\n        const decoded = jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default().verify(token, \"wANfQv8JNbvgjwgV\");\n        req.user = decoded;\n        return {\n            success: true\n        };\n    } catch (error) {\n        return {\n            success: false,\n            message: 'Invalid token',\n            status: 403\n        };\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL21pZGRsZXdhcmUvYXV0aGVudGljYXRlVG9rZW4uanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUMrQjtBQUNZO0FBR3BDLFNBQVNFLGFBQWFDLEdBQUc7SUFFOUIsTUFBTUMsUUFBUUQsSUFBSUUsT0FBTyxDQUFDQyxHQUFHLENBQUMsa0JBQWtCQyxNQUFNLElBQUksQ0FBQyxFQUFFO0lBRzdELElBQUksQ0FBQ0gsT0FBTztRQUNWLE9BQU87WUFBRUksU0FBUztZQUFPQyxTQUFTO1lBQTJCQyxRQUFRO1FBQUk7SUFDM0U7SUFFQSxJQUFJO1FBRUYsTUFBTUMsVUFBVVgsMERBQVUsQ0FBQ0ksT0FBTztRQUNsQ0QsSUFBSVUsSUFBSSxHQUFHRjtRQUNYLE9BQU87WUFBRUgsU0FBUztRQUFLO0lBQ3pCLEVBQUUsT0FBT00sT0FBTztRQUNkLE9BQU87WUFBRU4sU0FBUztZQUFPQyxTQUFTO1lBQWlCQyxRQUFRO1FBQUk7SUFDakU7QUFDRiIsInNvdXJjZXMiOlsid2VicGFjazovL2Fzc2lnbm1lbnRmdWxsLy4vc3JjL2FwcC9taWRkbGV3YXJlL2F1dGhlbnRpY2F0ZVRva2VuLmpzPzQwOGYiXSwic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCBqd3QgZnJvbSAnanNvbndlYnRva2VuJztcclxuaW1wb3J0IHsgTmV4dFJlc3BvbnNlIH0gZnJvbSAnbmV4dC9zZXJ2ZXInO1xyXG5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhdXRoZW50aWNhdGUocmVxKSB7XHJcblxyXG4gIGNvbnN0IHRva2VuID0gcmVxLmhlYWRlcnMuZ2V0KCdBdXRob3JpemF0aW9uJyk/LnNwbGl0KCcgJylbMV07XHJcblxyXG5cclxuICBpZiAoIXRva2VuKSB7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgbWVzc2FnZTogJ0F1dGhlbnRpY2F0aW9uIHJlcXVpcmVkJywgc3RhdHVzOiA0MDEgfTtcclxuICB9XHJcblxyXG4gIHRyeSB7XHJcbiBcclxuICAgIGNvbnN0IGRlY29kZWQgPSBqd3QudmVyaWZ5KHRva2VuLCBcIndBTmZRdjhKTmJ2Z2p3Z1ZcIik7XHJcbiAgICByZXEudXNlciA9IGRlY29kZWQ7IFxyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9OyBcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIG1lc3NhZ2U6ICdJbnZhbGlkIHRva2VuJywgc3RhdHVzOiA0MDMgfTtcclxuICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbImp3dCIsIk5leHRSZXNwb25zZSIsImF1dGhlbnRpY2F0ZSIsInJlcSIsInRva2VuIiwiaGVhZGVycyIsImdldCIsInNwbGl0Iiwic3VjY2VzcyIsIm1lc3NhZ2UiLCJzdGF0dXMiLCJkZWNvZGVkIiwidmVyaWZ5IiwidXNlciIsImVycm9yIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./src/app/middleware/authenticateToken.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/ms","vendor-chunks/semver","vendor-chunks/jsonwebtoken","vendor-chunks/jws","vendor-chunks/ecdsa-sig-formatter","vendor-chunks/safe-buffer","vendor-chunks/lodash.once","vendor-chunks/lodash.isstring","vendor-chunks/lodash.isplainobject","vendor-chunks/lodash.isnumber","vendor-chunks/lodash.isinteger","vendor-chunks/lodash.isboolean","vendor-chunks/lodash.includes","vendor-chunks/jwa","vendor-chunks/buffer-equal-constant-time"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fmovie%2F%5BmovieId%5D%2Froute&page=%2Fapi%2Fmovie%2F%5BmovieId%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fmovie%2F%5BmovieId%5D%2Froute.js&appDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Clenovo%5CDownloads%5Czip%202&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();